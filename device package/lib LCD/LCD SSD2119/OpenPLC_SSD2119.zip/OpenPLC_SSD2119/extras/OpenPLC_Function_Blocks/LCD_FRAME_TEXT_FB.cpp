/* OpenPLC FB: LCD_FRAME_TEXT
Inputs: EN BOOL, X UINT, Y UINT, TEXT STRING, FONT_SIZE USINT,
        FONT_COLOR UINT, BG_COLOR UINT, CLEAR_BG BOOL
Outputs: DONE BOOL, ERROR BOOL
*/
#include <stdint.h>
extern "C" uint8_t OpenPLC_LCD_FrameText(uint16_t x, uint16_t y, const char *text, uint8_t fontSize, uint16_t fontColor, uint16_t backgroundColor, uint8_t clearTextBackground);
static bool requestAccepted = false;
void setup() { requestAccepted = false; DONE = false; ERROR = false; }
void loop()
{
  DONE = false; ERROR = false;
  if (!EN) { requestAccepted = false; return; }
  if (requestAccepted) return;
  uint8_t ok = OpenPLC_LCD_FrameText((uint16_t)X, (uint16_t)Y, TEXT.c_str(), (uint8_t)FONT_SIZE, (uint16_t)FONT_COLOR, (uint16_t)BG_COLOR, CLEAR_BG ? 1U : 0U);
  if (ok != 0U) { requestAccepted = true; DONE = true; }
  else { ERROR = true; }
}