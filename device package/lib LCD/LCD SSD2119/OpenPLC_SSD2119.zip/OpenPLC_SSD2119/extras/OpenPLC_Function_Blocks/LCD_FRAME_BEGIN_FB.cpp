/* OpenPLC FB: LCD_FRAME_BEGIN
Inputs: EN BOOL, BG_COLOR UINT, CLEAR BOOL
Outputs: DONE BOOL, BUSY BOOL, ERROR BOOL
*/
#include <stdint.h>
extern "C" uint8_t OpenPLC_LCD_FrameBegin(uint16_t backgroundColor, uint8_t clearFrame);
extern "C" uint8_t OpenPLC_LCD_FrameBusy(void);
static bool requestAccepted = false;
void setup() { requestAccepted = false; DONE = false; BUSY = false; ERROR = false; }
void loop()
{
  DONE = false; ERROR = false; BUSY = false;
  if (!EN) { requestAccepted = false; return; }
  if (requestAccepted) return;
  if (OpenPLC_LCD_FrameBusy() != 0U) { BUSY = true; return; }
  uint8_t ok = OpenPLC_LCD_FrameBegin((uint16_t)BG_COLOR, CLEAR ? 1U : 0U);
  if (ok != 0U) { requestAccepted = true; DONE = true; }
  else { ERROR = true; }
}