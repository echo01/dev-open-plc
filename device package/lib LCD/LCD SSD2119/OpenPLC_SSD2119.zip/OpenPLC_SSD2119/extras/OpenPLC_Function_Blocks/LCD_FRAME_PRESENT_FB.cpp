/* OpenPLC FB: LCD_FRAME_PRESENT
Input: EN BOOL
Outputs: DONE BOOL, BUSY BOOL, ERROR BOOL
*/
#include <stdint.h>
extern "C" uint8_t OpenPLC_LCD_FramePresent(void);
extern "C" uint8_t OpenPLC_LCD_FrameBusy(void);
static bool requestAccepted = false;
void setup() { requestAccepted = false; DONE = false; BUSY = false; ERROR = false; }
void loop()
{
  DONE = false; ERROR = false; BUSY = false;
  if (!EN) { requestAccepted = false; return; }
  if (requestAccepted) { BUSY = OpenPLC_LCD_FrameBusy() != 0U; return; }
  uint8_t ok = OpenPLC_LCD_FramePresent();
  if (ok != 0U) { requestAccepted = true; DONE = true; BUSY = true; }
  else { ERROR = true; }
}